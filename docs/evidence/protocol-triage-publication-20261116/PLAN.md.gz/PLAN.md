# OWA triage publication proposal — not executed

Repository: public `dvrd/owa`. Exact reviewed head `0e1d22c3adc994baa8c5916cc89e0490bedab882` (two tooling commits: `5c9beba` and `0e1d22c`), based on published main `7965d81ad9e8c4d285f0345503a33d31048058a1`. Only ten workflow/protocol-tooling files change. The unrelated local ACK test/evidence commit b902091 is excluded.

[Exact patch](CHANGE.patch) and [prepared PR description](PULL_REQUEST.md).

Local validation:127 offline Python tests, actionlint, clean diff and independent selected review passed. No live upstream scan, runtime change, session access, new secret or provider action was used. The implementation defaults uncertain upstream behavior to a SPIKE and requires an explicitly reviewed target contract before producing a FIX task.

One approval may authorize pushing only these two reviewed commits to a new feature branch, opening its PR, waiting for the offline GitHub checks, and merging that same reviewed change into main only if those checks pass. Stop on unexpected remote changes, conflicts or failed checks; no force push or bypass. No other repository/default branch is changed.

Merging activates the existing daily/manual maintenance workflow with the new deduplication and triage behavior. It reads bounded public reference files and uses the existing LINEAR_API Actions secret to create/update the configured Linear tasks/spikes. It does not run an agent, adopt upstream code/versions, close compatibility reviews, pair accounts or send WhatsApp messages. No native/runtime or server deployment occurs.

Publication needs an exception to the user's earlier do-not-push instruction. Until explicitly approved, the candidate branches remain local and the existing GitHub workflow is unchanged.
