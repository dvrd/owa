The daily scan currently fingerprints whole snapshots, so one changing whatsmeow file creates another report repeating seven unchanged Baileys findings. This change records per-file change coverage across open, closed and archived reviews and appends new evidence with deterministic comment IDs, preserving human text and state.

Supported formatting/JSON equivalence and already-implemented dictionaries need no task. Other changes become source-mapped investigation spikes. A Todo implementation task requires an explicit reviewed target contract plus an owned indexed counterexample; newer upstream bytes alone never approve an update. No runtime source, protocol version, session state or dependencies are changed automatically.

Validation: 127 offline Python tests pass on the published baseline; actionlint and diff checks pass. Tests cover the three-snapshot regression, legacy coverage, malformed/paginated history, human edits, lost create/comment responses, compiler/build directives, lexical ambiguities and approved-contract refusal/promotion. Read-only live Linear queries confirmed the discovery and missing-comment query shapes; no actual upstream analysis or scan ran during implementation.

Only the default branch can scan or access Linear credentials; feature branches and PRs run offline tests. Writer runs serialize. No model API/key or hosted server is required. Existing unrelated unpublished ACK work is excluded.

Legacy mixed-source reviews can carry a routing-only scope comment, preserving prior coverage while directing future observations to the correct investigation. Scope markers cannot grant FIX readiness; conflicting markers stop the writer.
